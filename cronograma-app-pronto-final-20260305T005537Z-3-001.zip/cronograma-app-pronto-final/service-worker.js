/* Service Worker — offline total após primeiro load dos vendors */
const CACHE = 'cronograma-offline-v1';
const APP_SHELL = [
  './', './index.html', './styles.css', './app.js', './manifest.webmanifest',
  './icons/icon-192.png', './icons/icon-512.png',
  './vendor/chart.umd.min.js', './vendor/jspdf.umd.min.js', './vendor/jspdf.plugin.autotable.min.js'
];
self.addEventListener('install', evt => {
  evt.waitUntil(caches.open(CACHE).then(c => c.addAll(APP_SHELL)));
  self.skipWaiting();
});
self.addEventListener('activate', evt => {
  evt.waitUntil(caches.keys().then(keys => Promise.all(keys.map(k => k!==CACHE && caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', evt => {
  evt.respondWith(
    caches.match(evt.request).then(cached => cached || fetch(evt.request).then(resp => {
      const copy = resp.clone();
      caches.open(CACHE).then(cache => cache.put(evt.request, copy));
      return resp;
    }))
  );
});
