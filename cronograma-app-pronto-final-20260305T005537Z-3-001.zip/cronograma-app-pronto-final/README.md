# Cronograma PF + PRF — App instalável (PWA)

Este pacote está pronto para ser **instalado** (PWA) no celular/desktop e abrir offline (shell).
Para **gráficos** (Chart.js) e **PDF** (jsPDF + AutoTable) funcionarem **offline** no primeiro uso,
coloque os três arquivos reais em `./vendor/` com estes nomes:

- `chart.umd.min.js`  (Chart.js 4.5.1 UMD)
- `jspdf.umd.min.js`  (jsPDF 2.5.1 UMD)
- `jspdf.plugin.autotable.min.js` (AutoTable 3.8.2)

Depois, sirva localmente:
```bash
python -m http.server 8000
# abra http://localhost:8000
```
O navegador permitirá **Adicionar à tela inicial**.
