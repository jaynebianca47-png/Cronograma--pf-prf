/* =============================== 
 Cronograma PF + PRF — App Core (v2.2) 
 Dados salvos em localStorage 
 =============================== */ 
const LS_KEY = "cronograma_pf_prf_v2_2"; // nova versão do storage 
const $ = (sel, el = document) => el.querySelector(sel); 
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)]; 
const state = { 
 startDate: null, 
 endDate: null, 
 weekdayMin: 90, 
 weekendTotal: 180, 
 weekendSplit: true, 
 weeklyQs: 100, 
 replanMargin: 30, 
 carryQuestions: true, 
 raiseDaily: true, 
 exams: { PF: true, PRF: true }, 
 disciplines: {}, 
 planByDate: {}, 
 historyWeeks: [], 
 alerts: { enabled:false, weekdayTime:"19:00", weekendTime:"09:00", leadMin:10, sound:true, oneOff:{} }, 
 review: { enabled:true, percent:30, n:2, days:[1,3,6] }, 
 account: { alfaconEmail: "jaynebianca47@gmail.com", qcEmail: "jaynebianca47@gmail.com", copyOnOpen: true }, 
 _timers: [] 
};
/* (restante do app.js original continuará abaixo sem alterações) */
